import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;


public class Main {
    public static void main(String[] args) {

        List<Integer> list = new ArrayList<>(Arrays.asList(1, 2, 3, 4, 5));
        System.out.println(list);

        list.add(3,60);
        list.remove(0);
        System.out.println(list.contains(5)) ;
        System.out.println(list);

    }
}