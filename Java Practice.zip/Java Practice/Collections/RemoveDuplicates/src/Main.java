import java.util.Arrays;
import java.util.HashSet;
import java.util.List;


public class Main {
    public static void main(String[] args) {

        List<Integer> list = Arrays.asList(10,20,10,30,20,40,30,50);

        System.out.println("Before removing duplicates"+ list);

        HashSet<Integer> set = new HashSet<>(list);

        System.out.println("After Removing Duplicates " +set);

    }
}