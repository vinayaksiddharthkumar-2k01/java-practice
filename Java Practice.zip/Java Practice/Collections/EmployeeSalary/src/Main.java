import java.util.ArrayList;
import java.util.Collections;

public class Main {
    public static void main(String[] args) {

        ArrayList<Integer> list = new ArrayList<>();
        list.add(60000);
        list.add(30000);
        list.add(50000);
        list.add(40000);
        list.add(10000);
        list.add(20000);


        System.out.println("before sorting");
        System.out.println(list);

        Collections.sort(list);
        System.out.println("After Sorting");
        System.out.println(list);

        System.out.println("Lowest:"+list.getFirst());
        System.out.println("Highest:"+list.getLast());

        Collections.sort(list,Collections.reverseOrder());
        System.out.println("descending"+list);

        int average = 0;
        for (int i = 0 ; i<list.size() ; i++){
            average += list.get(i);

        }
        System.out.println("Average : "+ average/list.size());

    }
}