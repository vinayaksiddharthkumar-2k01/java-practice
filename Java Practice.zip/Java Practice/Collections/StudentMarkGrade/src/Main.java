import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ArrayList<Integer> list = new ArrayList<>();
        Scanner sc=new Scanner(System.in);
        System.out.println("enter student Marks");

        for(int i=0; i<5 ; i++){
         list.add(sc.nextInt());
        }
        System.out.println(list);

        int total = 0;
        for(int i=0;i<list.size();i++){
          total += list.get(i);
        }
        System.out.println("Total Marks :"+total);

        int avg = total/list.size();
        System.out.println("Average of Marks :"+avg);

        int count = 0;
        for(int i = 0 ; i<list.size();i++){
            if (list.get(i)>=avg){
              count++;
            }
        }System.out.println("Total students above average : " +count);

        Collections.sort(list);
        System.out.println("Highest Marks:"+list.getLast());

        Collections.sort(list,Collections.reverseOrder());
        System.out.println("Descending Order of Marks" +list);
    }

}