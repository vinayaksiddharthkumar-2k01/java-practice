import java.util.ArrayList;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        ArrayList<String> list = new ArrayList<>();

        System.out.println("Enter 5 Names");

        for(int i = 0 ; i<=4; i++){
            String names = scanner.nextLine();
            list.add(names);
        }
        System.out.println(list);

        System.out.println("Enter a student name to check");

        String check = scanner.nextLine();

        if(list.contains(check)){
            System.out.println("Student Found");
        }
        else System.out.println("Student Not Found");
    }
}