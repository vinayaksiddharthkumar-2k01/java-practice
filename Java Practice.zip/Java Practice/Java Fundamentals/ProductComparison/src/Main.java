//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Product p1 = new Product(1, "Mouse", 500, "Electronics");
        Product p2 = new Product(1, "Keyboard", 700, "Computer");

        System.out.println(p1.equals(p2));
        System.out.println(p1.hashCode()==p2.hashCode());
        System.out.println(p1.getClass());
        System.out.println(p1.id==p2.id);
        }
    }
