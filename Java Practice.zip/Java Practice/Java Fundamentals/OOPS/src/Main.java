//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {
        BankAccount account = new BankAccount(5000,"abc123");

        account.deposit(2000);
        account.withdraw(8000);
        System.out.println(account.getBalance());
    }
}