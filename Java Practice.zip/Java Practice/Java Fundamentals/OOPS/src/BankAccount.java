public class BankAccount {
    private String accountNumber;
    private double balance;

    public BankAccount(double balance, String accountNumber) {
        this.balance = balance;
        this.accountNumber = accountNumber;
    }
    void deposit(double amount){
       this.balance+=amount;
    }
    void withdraw(double amount){
    if(amount<=balance){
        this.balance-=amount;
    }
    else System.out.println("transaction declined");
    }

    double getBalance(){
        return balance;
    }
}
