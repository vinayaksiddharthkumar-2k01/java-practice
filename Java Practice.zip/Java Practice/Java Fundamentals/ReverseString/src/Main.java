//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        String str = "Java";
        String reverseStr = "";

        for (int i = str.length()-1 ; i>=0;i--){
            reverseStr+=str.charAt(i);
        }
        System.out.println(reverseStr);
    }
}