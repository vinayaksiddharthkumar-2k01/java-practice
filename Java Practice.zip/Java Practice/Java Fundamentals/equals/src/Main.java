
public class Main {
    public static void main(String[] args) {
    Employee e1 = new Employee(101,"Siddharth",20000);
    Employee e2 = new Employee(101,"Siddharth",20000);

        System.out.println(e1.equals(e2));

        System.out.println(e1.hashCode()==e2.hashCode());

        System.out.println(e1.hashCode());
        System.out.println(e2.hashCode());

    }

}