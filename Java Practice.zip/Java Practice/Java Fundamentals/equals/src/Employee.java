public class Employee {
    private int id;
    private String name;
    private double salary;

    public Employee(int id, String name, double salary) {
        this.id = id;
        this.name = name;
        this.salary = salary;
    }

    @Override
    public boolean equals(Object obj) {
        {

            if (this == obj) {
                return true;
            }

            if (!(obj instanceof Employee)) {
                return false;
            }
            Employee emp = (Employee) obj;
            return this.id == emp.id
                    && this.name.equals(emp.name)
                    && this.salary == emp.salary;
        }
}}
