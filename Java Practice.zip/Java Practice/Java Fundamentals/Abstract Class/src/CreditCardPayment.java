public class CreditCardPayment extends Payment{

    @Override
    void payment(double amount) {
        System.out.println("Payment done by Credit Card");
    }
}
