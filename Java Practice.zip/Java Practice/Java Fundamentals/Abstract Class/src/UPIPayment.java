public class UPIPayment extends Payment{

    @Override
    void payment(double amount) {
        System.out.println("Payment done by UPI");
    }
}
