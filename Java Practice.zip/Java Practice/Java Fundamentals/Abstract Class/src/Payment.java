public abstract class Payment {
    abstract void payment(double amount);
}
