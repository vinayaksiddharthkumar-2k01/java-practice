import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("1. Credit Card");
        System.out.println("2. UPI");

        int choice = scanner.nextInt();

        Payment payment;

        if (choice == 1) {
            payment = new CreditCardPayment();
        } else if (choice == 2) {
            payment = new UPIPayment();
        } else {
            System.out.println("Invalid choice");
            return;
        }

        System.out.print("Enter amount: ");
        double amount = scanner.nextDouble();

        payment.payment(amount);
    }
}