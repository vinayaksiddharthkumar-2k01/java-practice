public class Manager extends Employee {
     String department;

    public Manager(String name, double salary,String department){
        super(name, salary);
        this.department=department;
    }
    @Override
    void displayDetails(){
        System.out.println("Name :" + name + "salary :" + salary + "Dept :" + department );

    }

}

