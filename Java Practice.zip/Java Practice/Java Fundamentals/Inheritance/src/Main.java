//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Employee e = new Employee("siddharth",2000);
        Manager m = new Manager("Kumar",50000,"IT");

        e.displayDetails();
        m.displayDetails();

    }
}