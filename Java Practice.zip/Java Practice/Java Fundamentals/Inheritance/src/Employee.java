public class Employee {
    String name;
    double salary;

    public Employee(String name, double salary) {
        this.name = name;
        this.salary = salary;
    }

    void displayDetails(){
        System.out.println("Name :" + name + "salary :" + salary );

    }


}
