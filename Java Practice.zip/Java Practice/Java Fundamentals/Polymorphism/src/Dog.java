public class Dog extends Animal{

    @Override
    void soud() {
        System.out.println("dog barks");
    }
}
