//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

    Animal a1 = new Dog();
    Animal a2 = new Cat();

    a1.soud();
    a2.soud();
    }
}