public class Cat extends Animal{

    @Override
    void soud() {
        System.out.println("cat Meows");
    }
}
