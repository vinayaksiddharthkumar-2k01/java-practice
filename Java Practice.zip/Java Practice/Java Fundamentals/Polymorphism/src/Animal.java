public class Animal {

    void soud(){
        System.out.println("Animal Makes a sound");
    }
}
