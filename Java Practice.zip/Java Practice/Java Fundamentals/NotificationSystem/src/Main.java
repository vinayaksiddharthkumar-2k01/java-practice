import java.util.Arrays;
import java.util.List;

public class Main {
    public static void main(String[] args) {

        List<Notification> list = Arrays.asList(new SMSNotification(), new PushNotification(), new EmailNotification());

        for (Notification notification : list) {
            notification.send("Hello");
        }
    }
}