public abstract class Notification {
    abstract void send(String message);
}
