import java.util.Scanner;


public class Main {
    public static void main(String[] args) {

        int[] array = {1,2,3,4,5};

        Scanner sc = new Scanner(System.in);

        System.out.println("Enter the Array index");

        int a = sc.nextInt();

        try {
                System.out.println(array[a]);
        }
        catch (ArrayIndexOutOfBoundsException e){
            System.out.println("array size exceeded");
        }


    }
}