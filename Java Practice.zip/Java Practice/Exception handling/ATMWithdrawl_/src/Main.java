import java.util.Scanner;

public class Main {
    public static void main(String[] args) {

        ATM atm = new ATM();
        Scanner scanner = new Scanner(System.in);

        System.out.print("Enter amount to withdraw: ");
        double amount = scanner.nextDouble();

        try {
            atm.withdraw(amount);
        } catch (InsufficientBalanceException e) {
            System.out.println(e.getMessage());
        }

        scanner.close();
    }
}