import java.util.HashMap;

public class Main {
    public static void main(String[] args) {

        String word = "java is easy and java is powerful";

        HashMap<String, Integer> hashMap = new HashMap<>();

        String[] words = word.split(" ");

        for (int i = 0; i < words.length; i++) {

            if (hashMap.containsKey(words[i])) {
                hashMap.put(words[i], hashMap.get(words[i]) + 1);
            } else {
                hashMap.put(words[i], 1);
            }
        }

        System.out.println(hashMap);
    }
}