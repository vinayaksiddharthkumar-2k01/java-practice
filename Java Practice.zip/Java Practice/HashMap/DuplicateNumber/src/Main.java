import java.util.HashMap;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        int[] numbers = {10,20,30,10,40,20,50,30,30};

        HashMap<Integer,Integer> hashMap = new HashMap<>();

        for (int i = 0; i< numbers.length;i++){
        }
        System.out.println(hashMap);
    }
}