import java.util.HashMap;
import java.util.Scanner;


public class Main {
    public static void main(String[] args) {
        HashMap<String,Integer> hashMap = new HashMap<>();

        hashMap.put("Siddharth",67);
        hashMap.put("kumar",76);
        hashMap.put("vinayak",69);
        hashMap.put("Ganesh",96);
        hashMap.put("Krishav",77);

        
        System.out.println(hashMap);

        Scanner scanner = new Scanner(System.in);
        System.out.println("Enter the student Name :");
        String searchByName = scanner.nextLine();

        if (hashMap.containsKey(searchByName)){
            System.out.println(hashMap.get(searchByName));
        }
        else System.out.println("not found");

        hashMap.replace("vinayak",90);
        hashMap.remove("kumar");
        System.out.println("Final Map:"+hashMap);


    }
}