import java.util.Optional;


public class Main {
    public static void main(String[] args) {

        String name = null;

        Optional<String> value = Optional.ofNullable(name);
        System.out.println(value.orElse("Name not available"));

    }
    }
