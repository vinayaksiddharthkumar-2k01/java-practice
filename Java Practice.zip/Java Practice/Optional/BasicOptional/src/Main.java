import java.util.Optional;


public class Main {
    public static void main(String[] args) {

        Optional<String> value = Optional.of("Java");

        if (value.isPresent()){
            System.out.println(value.get());
        }

        
        value.ifPresent(System.out::println);

     }
}