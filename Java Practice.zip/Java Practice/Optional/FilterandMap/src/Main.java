import java.util.Optional;

public class Main {
    public static void main(String[] args) {

        String name = "Rahul";

        Optional<String> optional=Optional.ofNullable(name);

        optional=optional.filter(x -> x.length() > 3).map(x -> x.toUpperCase());

        System.out.println(optional.orElse("Name is invalid"));


    }
}