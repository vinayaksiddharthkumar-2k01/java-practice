import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.Scanner;

//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Scanner scanner = new Scanner(System.in);
        Map<Integer, String> employees = new HashMap<>();

        employees.put(101, "Rahul");
        employees.put(102, "Amit");
        employees.put(103, "Vijay");

        System.out.println("Enter the Employee ID");
        int empID=scanner.nextInt();

        Optional<String> result = Optional.ofNullable((employees.get(empID)));

        System.out.println(result.orElse("Employee not found"));

    scanner.close();
    }
}