import java.util.Arrays;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;


public class Main {
    public static void main(String[] args) {

        List<Integer> salaries =
                Arrays.asList(25000, 45000, 30000, 60000, 40000, 75000);

       List<Integer> result = salaries.stream().filter(n->n>40000).sorted(Collections.reverseOrder()).collect(Collectors.toList());
        System.out.println(result);

        
    }
}