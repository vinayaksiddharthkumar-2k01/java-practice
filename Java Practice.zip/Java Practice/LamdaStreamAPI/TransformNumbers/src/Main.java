import java.util.Arrays;
import java.util.List;


public class Main {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(2,4,6,8,10);

        numbers.stream().map(n->n*n).forEach(System.out::println);
    }
}