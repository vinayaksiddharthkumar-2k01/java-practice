import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) {
        List<Integer> numbers = Arrays.asList(15,4,23,8,42,16,7,30);

        List<Integer> result = numbers.stream().filter(n->n>10).map(n->n*n).sorted().collect(Collectors.toList());
        System.out.println(result);
    }
}