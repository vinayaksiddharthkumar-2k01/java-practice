public interface Calculator {
    double  operations(double a, double b);
}
