//TIP To <b>Run</b> code, press <shortcut actionId="Run"/> or
// click the <icon src="AllIcons.Actions.Execute"/> icon in the gutter.
public class Main {
    public static void main(String[] args) {

        Calculator add = (a, b) -> a + b;
        System.out.println(add.operations(10, 20));

        Calculator sub = (a, b) -> a - b;
        System.out.println(sub.operations(10, 20));

        Calculator div = (a, b) -> a / b;
        System.out.println(div.operations(30, 20));

        Calculator mul = (a, b) -> a * b;
        System.out.println(mul.operations(10, 20));
    }
}