import java.util.Arrays;
import java.util.List;


public class Main {
    public static void main(String[] args) {

        List<Integer> nums = Arrays.asList(10,25,30,45,50,65,79);
        nums.stream().filter(n->n>40).forEach(System.out::println);

    }
}